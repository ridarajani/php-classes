<?php
    define ('BALANCE' , "your current balance is ");
    define ('WITHDRAW' , "you withdraw ");
    define ('DEPOSIT' , "you deposit ");
?>