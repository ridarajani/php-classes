<?php
    define ('NAME' , "Name is required");
    define ('FATHER' , "Father is required");
    define ('GENDER' , "Gender is required");
    define ('CITY' , "City is required");
    define ('SKILL' , "Skills are required");
    define ('SUBMITTED' , "Your form has been submitted!!");
?>