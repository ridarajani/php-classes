<?php 
$information = [
    [
        "Unique-id" => 001,
        "Name" => "Sheruj",
        "Age" => 5,
        "PhoneNumber" => "021254555454"
    ],
    [
        "Unique-id" => 002,
        "Name" => "Aariz",
        "Age" => 4,
        "PhoneNumber" => "033554564864"
    ],
];
$credentials=[
    [
        "unique-id" => 001,
        "Email" => "test@example.com",
        "Password" => "000000",
        "userInfo" => 02
    ],
    [
        "unique-id" => 002,
        "Email" => "testtwo@example.com",
        "Password" => "111111",
        "userInfo" => 01
    ]
];

?>