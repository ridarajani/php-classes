<?php
    define ('INVALID' , "Invalid Email or Password");
?>